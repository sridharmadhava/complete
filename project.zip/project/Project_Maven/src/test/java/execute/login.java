package execute;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.openqa.selenium.Alert;
 

public class login {
	

		WebDriver driver;

		By signup = By.id("signin2");
		By signupUsername = By.id("sign-username");
		By signupPassword = By.id("sign-password");
		By signupButton = By.xpath("//button[@onclick='register()']");
		By signupClose = By.xpath("//*[@id=\"signInModal\"]/div/div/div[3]/button[1]");
		By login = By.id("login2");
		By loginUsername = By.id("loginusername");
		By loginPassword = By.id("loginpassword");
		By loginButton = By.xpath("//button[@onclick='logIn()']");
		By loginClose = By.xpath("//*[@id=\"logInModal\"]/div/div/div[3]/button[1]");

		By addToCartM = By.xpath("//a[text()='Samsung galaxy s6']");
		By addToCartButton = By.xpath("//a[@onclick='addToCart(1)']"); 
		By showCart = By.id("cartur");
		By placeOrder = By.xpath("//*[@id=\"page-wrapper\"]/div/div[2]/button");

		By namePO = By.id("name");
		By countryPO = By.id("country");
		By cityPO = By.id("city");
		By cardPO = By.id("card");
		By monthPO = By.id("month");
		By yearPO = By.id("year");
		By purchase = By.xpath("//*[@id=\"orderModal\"]/div/div/div[3]/button[2]");
		By okPurchaseButton = By.xpath("/html/body/div[10]/div[7]/div/button");
		//button[@tabindex='1']
		By clickContact = By.xpath("//a[@data-target='#exampleModal']");
		By clickLogout = By.xpath("//*[@id=\"logout2\"]");
		@Test
	  public void clickSignup() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(signup).click();
	  }
	  public void enterUsername(String uname) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement username = driver.findElement(signupUsername);
		  username.sendKeys(uname);
	  }
	  public void enterPassword(String pword) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement password = driver.findElement(signupPassword);
		  password.sendKeys(pword);
	  }
	  public void clickSignupButton() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(signupButton).click();
	  }
	  public void alertHandle() {
		  Alert alert = driver.switchTo().alert();
	      alert.accept();
	  }
	  public void closeSignup() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(signupClose).click();
	  }
	  public void clickLogin() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(login).click();
	  }
	  public void enterLoginUsername(String uname) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebElement username = driver.findElement(loginUsername);
		username.sendKeys(uname);
	  }
	  public void enterLoginPassword(String pword) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebElement password = driver.findElement(loginPassword);
		password.sendKeys(pword);
	  }
	  public void clickLoginButton() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(loginButton).click();
	  }
	  public void closeLogin() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(loginClose).click();
	  }

	  public void addMobile() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(addToCartM).click();
	  }
	     public void clickAddToCart() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    	  driver.findElement(addToCartButton).click();
	      }
	 
	  
	  public void clickCart() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		   driver.findElement(showCart).click();  
	  }
	  public void clickPlaceOrder() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(placeOrder).click();
	  }

	  public void enterPOName(String name) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement poName = driver.findElement(namePO);
		  poName.sendKeys(name);
	  }
	  public void enterPOCountry(String country) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement poCountry = driver.findElement(countryPO);
		  poCountry.sendKeys(country);
	  }
	  public void enterPOCity(String city) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement poCity = driver.findElement(cityPO);
		  poCity.sendKeys(city);
	  }
	  public void enterPOCard(String card) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement poCard = driver.findElement(cardPO);
		  poCard.sendKeys(card);
	  }
	  public void enterPOMonth(String month) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement poMonth = driver.findElement(monthPO);
		  poMonth.sendKeys(month);
	  }
	  public void enterPOYear(String year) {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  WebElement poYear = driver.findElement(yearPO);
		  poYear.sendKeys(year);
	  }
	  public void clickPurcharse() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(purchase).click(); 
	  }
	  public void clickOkPurchase() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(okPurchaseButton).click();  
	  }
	  public void clickOnContactbu() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(clickContact).click();  
	  }
	  

	  public void clickLogout() {
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(clickLogout).click();
	  }
	  public  login(WebDriver driver) {
		  this.driver = driver;
	  }
//	public void okPurchaseButton() {
//		// TODO Auto-generated method stub
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		driver.findElement(okPurchaseButton).click();  
//		
//	}

	}