package runner;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
 
import execute.login;

 
public class SignInExecutor {
  
	WebDriver driver;
	@Test
  public void runner() throws IOException, InterruptedException {
	  driver = new ChromeDriver();
	  FileReader fileReader = new FileReader("C:\\Users\\Sridhar.mandava\\Desktop\\project\\Project_Maven\\src\\test\\java\\runner\\login_credentials.properties");
	  Properties p = new Properties();
	  p.load(fileReader);
	  driver.get(p.getProperty("url"));
	  login element = new login(driver);
	  Thread.sleep(1000);
	  element.clickSignup();
	  Thread.sleep(1000);
	  element.enterUsername(p.getProperty("username"));
	  Thread.sleep(1000);
	  element.enterPassword(p.getProperty("password"));
	  Thread.sleep(3000);
	  element.clickSignupButton();
	  
	  
	  Thread.sleep(4000);
	  element.alertHandle();
	  Thread.sleep(4000);
      element.closeSignup();
      
      
      element.clickLogin();
      Thread.sleep(1000);
      element.enterLoginUsername(p.getProperty("username"));
      Thread.sleep(1000);
      element.enterLoginPassword(p.getProperty("password"));
      element.clickLoginButton();
      
      
      element.closeLogin();
     
      Thread.sleep(3000);
      element.addMobile();
      Thread.sleep(3000);
      element.clickAddToCart();
      
      Thread.sleep(3000);
	  element.alertHandle();
	  Thread.sleep(3000);
	  
	  
	  Thread.sleep(1000);
	  element.clickCart();
	  Thread.sleep(1000);
	  
	  Thread.sleep(2000);
	  element.clickPlaceOrder();
	  
	  Thread.sleep(1000);
	  element.enterPOName(p.getProperty("poname"));
	  Thread.sleep(1000);
	  element.enterPOCountry(p.getProperty("pocountry"));
	  Thread.sleep(1000);
	  element.enterPOCity(p.getProperty("pocity"));
	  Thread.sleep(1000);
	  element.enterPOCard(p.getProperty("pocard"));
	  Thread.sleep(1000);
	  element.enterPOMonth(p.getProperty("pomonth"));
	  Thread.sleep(1000);
	  element.enterPOYear(p.getProperty("poyear"));
	  Thread.sleep(1000);
	  System.out.println("jhgjhg");
	  element.clickPurcharse();
      Thread.sleep(1000);
      
      System.out.println("ghjgg");
      element.clickOkPurchase();
      
      System.out.println("fahim");
      element.clickOnContactbu();
      Thread.sleep(5000);
      element.clickLogout();
	}

	@AfterTest
	public void afterTest() {
	
		//driver.quit();
}
}