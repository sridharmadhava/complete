function Hi(){
    console.log("Namasate India");

}

Hi();