export const name:any[]=[
    {username:"performance_glitch_user",password:"secret_sauce",strmsg:"1st user",namef:"sridhar",namel:"M",pin:"524409"},
    {username:"standard_user",password:"secret_sauce",strmsg:"2nd user",namef:"hemanth",namel:"t",pin:"524409"},
    {username:"problem_user",password:"secret_sauce",strmsg:"3rd user",namef:"kalyan",namel:"b",pin:"524409"}
    
    //{username:"locked_out_user",password:"secret_sauce",strmsg:"4rd user",namef:"likith",namel:"b",pin:"524409"}
    
]