import { test, expect } from '@playwright/test';
import { LoginPage } from './page/LoginPage'
// import { users } from '../pages/Credintials';
import {name} from'./page/credentials'
for(let user of name){
    test(`${user.strmsg}`, async ({ page }) => {
    const objlogin = new LoginPage(page);
    await objlogin.goto();
    await objlogin.login(user.username,user.password,user.namef,user.namel,user.pin);
    await objlogin.logout();
    await page.pause();
 
 
 
})
}
// import { test, expect } from '@playwright/test';
// import { LoginPage } from './page/LoginPage';
// // import { users } from '../pages/Credintials';
// test(`Testing`, async ({ page }) => {
//     const objlogin = new LoginPage(page);
//     await objlogin.goto();
//     await objlogin.login("standard_user", "secret_sauce", "Raja", " P", "621314");
//     await objlogin.logout();
//     // await page.pause();
 
 
 
// })