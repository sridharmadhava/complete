package pract_TestNg;

import org.testng.annotations.Test;

public class RunnerClass {
  @Test
  public void f() {
  }
}
