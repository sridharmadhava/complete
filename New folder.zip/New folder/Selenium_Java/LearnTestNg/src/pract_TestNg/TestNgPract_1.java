package pract_TestNg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
//import org.testng.reporters.jq.Main;

public class TestNgPract_1 {
  @Test
  public void login() throws InterruptedException {
	  
	  
	  
	WebDriver wd = new ChromeDriver();
	wd.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	
	wd.manage().window().maximize();
	
	wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	
 	
	WebElement e = wd.findElement(By.xpath("//input[@name=\"username\"]"));
	e.sendKeys("Admin");
	wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	
	
	WebElement e1 = wd.findElement(By.xpath("//input[@type=\"password\"]"));
	e1.sendKeys("admin123");
	wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	
	WebElement loginButtton = wd.findElement(By.xpath("//button[@type=\"submit\"]"));
	loginButtton.click();
	wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	
	System.out.println(wd.getTitle());
	
	//wd.close();
  }
}
