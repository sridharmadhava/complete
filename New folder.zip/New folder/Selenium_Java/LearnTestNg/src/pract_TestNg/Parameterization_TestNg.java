package pract_TestNg;

import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Parameterization_TestNg {
	
	WebDriver wd = new ChromeDriver();
	
  @Test
  @Parameters({"Username", "password"})
  public void login(String Username, String password) {
	  
	  wd.get("https://www.saucedemo.com/v1/");
	  WebElement Username1 = wd.findElement(By.id("user-name"));
	  Username1.sendKeys(Username);
	  WebElement password1 = wd.findElement(By.id("password"));
	  password1.sendKeys(password);
	  WebElement login = wd.findElement(By.id("login-button"));
	  login.click();
	  
  }
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
