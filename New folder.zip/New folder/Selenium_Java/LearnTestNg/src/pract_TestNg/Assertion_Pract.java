package pract_TestNg;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertion_Pract {
  @Test
  public void f() {
	  
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://www.google.com/");
	  
	  SoftAssert sa = new SoftAssert();
	  
	  String expTitle = wd.getTitle();
	  String actTitle = "hgjgoogle";
	  
	  sa.assertEquals(expTitle, actTitle);
	  System.out.println("Test complete");
	  sa.assertAll();
  }
}
