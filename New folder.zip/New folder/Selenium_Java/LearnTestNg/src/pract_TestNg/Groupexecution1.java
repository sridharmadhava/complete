package pract_TestNg;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class Groupexecution1 {
	  @Test (groups = {"smoke"})
	  public void Test1() {
		  System.out.println("from Test1");
	  }
	  
	  @Test(groups = {"sanity"})
	  public void Test2() {
		  System.out.println(" from Test2");
	  }
	  
	  @Test(groups = {"sanity"})
	  public void Test3() {
		  System.out.println("from Test3");
	  }
	  
	  @Test(groups = {"sanity"})
	  public void Test4() {
		  System.out.println(" from Test4");
	  }
	  
	  @Test(groups = {"smoke"})
	  public void Test5() {
		  System.out.println("Hi from Test5");
	  }
	  
	  
	  @Test(groups = {"sanity"})
	  public void Test6() {
		  System.out.println("Hi from Test6");
	  }
	  
	  @Test(groups = {"smoke"})
	  public void Test7() {
		  System.out.println("Hi from Test7");
	  }
	}
