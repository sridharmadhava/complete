package pract_TestNg;

import java.io.FileReader;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Properity {
  @Test
  public void f() throws Exception{
	  FileReader fr = new FileReader("C:\\Users\\Sridhar.mandava\\eclipse-workspace\\selenium\\LearnTestNg\\src\\pract_TestNg\\Test_ng.properties");
	  Properties p = new Properties();
	  p.load(fr);
	  WebDriver d= new ChromeDriver();
	  d.get(p.getProperty("Url"));
	  
	  d.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	  
	  //d.get(p.getProperty("Url1"));
	  
	  d.findElement(By.id("APjFqb")).sendKeys(p.getProperty("search"));
	  d.findElement(By.xpath("//input[@type=\"submit\"]")).submit();
  }
}
