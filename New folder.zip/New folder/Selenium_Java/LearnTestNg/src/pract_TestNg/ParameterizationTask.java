package pract_TestNg;

import org.testng.annotations.Test; 
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
 
import java.time.Duration;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.SkipException;
import org.testng.annotations.AfterTest;
 
public class ParameterizationTask {
	WebDriver wb=new ChromeDriver();
  @Test
  @Parameters({"fname","lname","address","mailID","mobile","skill"})
  public void formfilling(String fname,String lname,String address,String mailID,String mobile, String skill ) {
	  wb.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
	  WebElement w=wb.findElement(By.xpath("//input[@placeholder='First Name']"));
	  w.sendKeys(fname);
	  WebElement w1=wb.findElement(By.xpath("//input[@placeholder='Last Name']"));
	  w1.sendKeys(lname);
	  WebElement w2=wb.findElement(By.xpath("//textarea[@rows='3']"));
	  w2.sendKeys(address);
	  WebElement w3=wb.findElement(By.xpath("//input[@type='email']"));
	  w3.sendKeys(mailID);
	  WebElement w4=wb.findElement(By.xpath("//input[@type='tel']"));
	  w4.sendKeys(mobile);
	  Select s=new Select(wb.findElement(By.id("Skills")));
	  s.selectByVisibleText(skill);
 
	
	  
	  
  }
  @BeforeTest
  public void beforeTest() {
	  wb.get("https://demo.automationtesting.in/Register.html");
	  
  }
 
  @AfterTest
  public void afterTest() {
	  throw new SkipException("skiping");
  }
 
}