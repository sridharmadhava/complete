package pract_TestNg;

import org.testng.SkipException;
import org.testng.annotations.Test;

public class Structureofperiority_in_TestNg {

  @Test(priority = 'a')
  public void C() {
	  throw new SkipException("Not Working");
	  //System.out.println("hey :3");
  }
  
  @Test(enabled = true)
  public void D() {
	  System.out.println("hey :4");
  }
  
  @Test(priority = 3)
  public void E() {
	  System.out.println("Hey :5");
  }
  @Test(priority = 4)
  public void A() {
	  System.out.println("hey : 1");
  }
  @Test(priority = 5)
  public void B() {
	  System.out.println("Hey : 2");
  }
}
