package pract_TestNg;

import org.testng.annotations.Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;

public class testtrack_Dataprovider {
  @Test(dataProvider = "dp")
  public void f(String username, String password) {
	  
	  WebDriver wd = new ChromeDriver();
		wd.get("https://testtrack.org/login-demo");
		
		wd.manage().window().maximize();
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		WebElement un = wd.findElement(By.id("username"));
		un.sendKeys(username);
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		WebElement ps = wd.findElement(By.id("password"));
		ps.sendKeys(password);
		
		WebElement au = wd.findElement(By.id("remember-me"));
		au.click();
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		WebElement login = wd.findElement(By.id("login-submit"));
		login.click();
		
		wd.close();
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "testuser", "password123" },
      new Object[] { "Sridhar", "ramu" },
    };
  }
}
