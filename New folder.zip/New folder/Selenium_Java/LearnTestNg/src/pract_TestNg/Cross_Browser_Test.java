package pract_TestNg;


//import com.beust.jcommander.Parameter;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;

public class Cross_Browser_Test {
	WebDriver driver ;
  @Parameters({"browser"})
  @Test
  public void login(String browser) throws Exception {
	  if( browser.equalsIgnoreCase("Chrome"))
	  {
		   driver = new ChromeDriver();
		   driver.get("https://testtrack.org/login-demo");
		  
	  }
	  else if(browser.equalsIgnoreCase("Edge")) {
		 driver = new EdgeDriver();
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		  }
	  else if(browser.equalsIgnoreCase("Firefox")) {
		  driver = new FirefoxDriver();
		  driver.get("https://www.google.com/");
	  }
	  else {
		 throw new Exception("Invilad");
	  }
	  
	 
	  //driver.get("https://testtrack.org/login-demo");
		
//	  driver.manage().window().maximize();
//		
//	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
  }
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
