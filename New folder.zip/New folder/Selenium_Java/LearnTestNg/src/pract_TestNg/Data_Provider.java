package pract_TestNg;

import org.testng.annotations.Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;

public class Data_Provider {
  @Test(dataProvider = "dp")
  public void login(String username, String password) {
	  
	  WebDriver wd = new ChromeDriver();
		wd.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		wd.manage().window().maximize();
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		WebElement un = wd.findElement(By.xpath("//input[@placeholder='Username']"));
		un.sendKeys(username);
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		WebElement ps = wd.findElement(By.xpath("//input[@placeholder='Password']"));
		ps.sendKeys(password);
		
		WebElement login = wd.findElement(By.xpath("//button[@type='submit']"));
		login.click();
		
		//wd.close();
		wd.quit();
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "Admin", "admin123" },
      new Object[] { "ramu", "admin453" },
      new Object[] { "Sridhar", "RAmuujjk" },
      new Object[] { "Hey", "namaste" },
      new Object[] { "chimtu", "admin453" },
    };
  }
}
