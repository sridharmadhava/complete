package pract_TestNg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Open_multi_Brow {
	WebDriver driver;
  @Test(priority = 1)
  
  public void Loginchrome() {
	  
		WebDriver driver = new ChromeDriver();
		driver.get("https://ess.changepond.com/#/");
		WebElement id = driver.findElement(By.id("empid"));
		id.sendKeys("4726");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebElement pass = driver.findElement(By.name("password"));
		pass.sendKeys("8500");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebElement btn = driver.findElement(By.xpath("//button[@type='submit']"));
		btn.click();
	}
  
 @Test(priority = 2)
  
 public void LoginEdge() {
		WebDriver driver = new EdgeDriver();
		driver.get("https://ess.changepond.com/#/");
		WebElement id = driver.findElement(By.id("empid"));
		id.sendKeys("4726");
		WebElement pass = driver.findElement(By.name("password"));
		pass.sendKeys("8500");
		WebElement btn = driver.findElement(By.xpath("//button[@type='submit']"));
		btn.click();
 }
 @Test(priority = 3)
 
 public void LoginFirefox() {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://ess.changepond.com/#/");
		WebElement id = driver.findElement(By.id("empid"));
		id.sendKeys("4726");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebElement pass = driver.findElement(By.name("password"));
		pass.sendKeys("8500");
		WebElement btn = driver.findElement(By.xpath("//button[@type='submit']"));
		btn.click();
 }
}
