package pract_TestNg;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class TestNgPract_2 {
 WebDriver wd = new ChromeDriver();;
	
	@Test
  
  public void login() {
	  
	//  WebDriver wd = null;
	WebElement e = wd.findElement(By.xpath("//input[@name=\"username\"]"));
		e.sendKeys("Admin");

		
		
		WebElement e1 = wd.findElement(By.xpath("//input[@type=\"password\"]"));
		e1.sendKeys("admin123");
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		WebElement loginButtton = wd.findElement(By.xpath("//button[@type=\"submit\"]"));
		loginButtton.click();
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		System.out.println(wd.getTitle());
		
		
  }
  @BeforeTest
  public void browsersetup() {
	  
		wd.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		wd.manage().window().maximize();
		
		
  }
  

  @AfterTest
  public void afterTest() {
	  wd.close();
  }

}
