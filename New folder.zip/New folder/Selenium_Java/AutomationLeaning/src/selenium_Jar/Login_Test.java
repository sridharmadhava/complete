package selenium_Jar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Test {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver drop = new ChromeDriver();
		drop.manage().window().maximize();
		Thread.sleep(4000);
		drop.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		//Thread.sleep(3500);
		
		drop.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("sraidhar");
		
		Thread.sleep(2000);
		
		drop.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("Ramu");
		
		drop.findElement(By.xpath("//button[@type='submit']")).click();
		
		Thread.sleep(2000);
		
		WebElement error = drop.findElement(By.xpath("//p[@class='oxd-text oxd-text--p oxd-alert-content-text']"));
		
		System.out.println("Enter valid credentials : " + error.getText());

	}

}
