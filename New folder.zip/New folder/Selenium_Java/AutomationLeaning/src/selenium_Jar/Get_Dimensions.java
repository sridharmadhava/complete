package selenium_Jar;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_Dimensions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver d = new ChromeDriver();
		String s= "https://www.saucedemo.com/v1/";
		d.get(s);
		Dimension dia1 = new Dimension(600, 800);
		d.manage().window().setSize(dia1);
		

	}

}
