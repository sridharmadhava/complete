package selenium_Jar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElement_Pract 
{
	public static void main(String[] args) throws InterruptedException {
		WebDriver wd=new ChromeDriver();
		wd.get("https://demoqa.com/automation-practice-form");
		//wd.manage().window().maximize();
//		Thread.sleep(1500);
//		
//		wd.findElement(By.id("firstName")).click();
//		wd.findElement(By.id("firstName")).sendKeys("Raju");
//		Thread.sleep(1500);
//		System.out.println();
//		wd.findElement(By.id("firstName")).clear();
//		Thread.sleep(1500);
//		wd.findElement(By.id("firstName")).sendKeys("Raja P");
//		Thread.sleep(1500);
		
		WebElement we=wd.findElement(By.id("firstName"));
		we.click();
		we.sendKeys("Ramu");
		Thread.sleep(1500);
//		we.clear();
//	
		System.out.println(we.getSize());
		System.out.println(we.isEnabled());
		System.out.println(we.isDisplayed());
		WebElement we1 = wd.findElement(By.id("submit"));
		System.out.println(we.getLocation());
		System.out.println(we.getTagName());
		System.out.println();
		//System.out.println(we.getLocation());
		System.out.println();
		
		System.out.println(we.getText());
		System.out.println(we.getAttribute("value"));

		System.out.println(we1.isSelected());
		
		
		
		
	}

}
