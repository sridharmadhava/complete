package selenium_Jar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;

public class Class_1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd = new ChromeDriver(); //To open Chromedriver
		String s = "https://www.w3schools.com/ ";
		String Ss =wd.getTitle();
		System.out.println(Ss);
		
		String s1= wd.getCurrentUrl();
		System.out.println(s1);
		
		wd.get(s);
//		wd.manage().window().maximize();
//		wd.manage().window().maximize();
		
		Thread.sleep(2000);
	
		
		wd.close();
		//		wd.close();
		
		
		

		
		
		

	}

}
