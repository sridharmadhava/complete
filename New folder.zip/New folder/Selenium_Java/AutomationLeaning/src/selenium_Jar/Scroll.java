package selenium_Jar;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scroll {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver drop = new ChromeDriver();
		drop.manage().window().maximize();
		Thread.sleep(4000);
		drop.get("https://demo.automationtesting.in/Register.html");
		
		WebElement s =drop.findElement(By.id("Button1"));

		
		JavascriptExecutor Je = (JavascriptExecutor)drop;
		Je.executeScript("arguments[0].scrollIntoView();",s);
		
		Thread.sleep(3000);
		//Je.executeScript("scroll(-150,0)");
		

	}

}
