package selenium_Jar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Task {

    public static void main(String[] args) throws Exception {
       

        WebDriver wd = new FirefoxDriver();
        
        Thread.sleep(2000);

        wd.manage().window().maximize();

        Thread.sleep(2000);
        wd.get("https://workspace.google.com/intl/en-US/gmail/");

        
        String title = wd.getTitle();
        System.out.println(title);

       
        String expectedTitle = "Welcome";
        if (title.equals(expectedTitle)) {
            System.out.println("Passed");
        } else {
            System.out.println("Failed");
        }

    
        System.out.println("Current URL: " + wd.getCurrentUrl());


        Thread.sleep(3000);

       
        wd.close();
    }
}
