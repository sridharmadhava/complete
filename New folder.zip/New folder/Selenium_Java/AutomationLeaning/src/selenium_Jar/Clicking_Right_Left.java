package selenium_Jar;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Clicking_Right_Left {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		WebDriver wd = new ChromeDriver();
		wd.get("https://www.tutorialspoint.com/selenium/practice/login.php");
		WebElement user = wd.findElement(By.id("email"));
		Actions act = new Actions(wd);
		act.moveToElement(user);
		act.contextClick().build().perform();
		user.sendKeys("Ramuuuu");
		act.doubleClick(user).build().perform();
		
		wd.close();
		

	}

}
