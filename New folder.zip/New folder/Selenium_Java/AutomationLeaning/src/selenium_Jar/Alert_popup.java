package selenium_Jar;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert_popup 
{
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver d = new ChromeDriver();
		d.get("https://demo.automationtesting.in/Alerts.html");
		
		d.manage().window().maximize();
		
		WebElement Button = d.findElement(By.xpath("//button[@onclick='alertbox()']"));
		Button.click();
		
		//org.openqa.selenium.Alert alert = d.switchto().alert();
		
		Alert alert = d.switchTo().alert();
		Thread.sleep(2000);
		System.out.println(alert.getText());
		alert.accept();
		
		Thread.sleep(4000);
		
		
		d.findElement(By.xpath("//a[@href=\"#CancelTab\"]")).click();
		//click.click();
		
		Thread.sleep(3000);
		
		WebElement Button1 = d.findElement(By.xpath("//button[@onclick='confirmbox()']"));
		Button1.click();
		
		//org.openqa.selenium.Alert alert = d.switchto().alert();
		
		Alert alert1 = d.switchTo().alert();
		Thread.sleep(2000);
		System.out.println(alert1.getText());
		alert1.dismiss();
		
		d.findElement(By.xpath("//a[@href=\"#Textbox\"]")).click();
		//click.click();
		
		Thread.sleep(3000);
		
		WebElement Button2 = d.findElement(By.xpath("//button[@onclick='promptbox()']"));
		Button1.click();
		Thread.sleep(2000);
		//org.openqa.selenium.Alert alert = d.switchto().alert();
		
		Alert alert2 = d.switchTo().alert();
		Thread.sleep(2000);
		System.out.println(alert1.getText());
		alert2.accept();
	}

}
