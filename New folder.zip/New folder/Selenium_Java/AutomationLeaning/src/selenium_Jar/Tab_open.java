package selenium_Jar;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WindowType;
import java.util.Set;

public class Tab_open {


    	    public static void main(String[] args) {
    	        
    	       // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");
    	        WebDriver driver = new ChromeDriver();

    	        String prevwin = driver.getWindowHandle();
    	        driver.get("https://www.changepond.com/");
    	        String originalTabHandle = driver.getWindowHandle(); 
    	        
    	        //2
    	        
    	        String secondwin = driver.getWindowHandle();
    	        driver.switchTo().newWindow(WindowType.TAB);
    	        driver.get("https://www.apple.com/in/iphone/");

    	       //3
    	        driver.switchTo().newWindow(WindowType.TAB);
    	        driver.get("https://www.w3schools.com/");
    	        String thirdwin = driver.getWindowHandle();
    	        
    	        
    	        
    	        driver.switchTo().window(prevwin);
    	        driver.switchTo().window(secondwin);
    	        driver.switchTo().window(thirdwin);
    	        
    	        //driver.switchTo().window(thirdwin);
    	        
     	       
     	       

    
    	        //driver.switchTo().window(originalTabHandle);

    	     
    	        // ...

    	        
    	         //driver.close(); // Uncomment to close all tabs/windows
    	    }
    	}
      
