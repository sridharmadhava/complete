package selenium_Jar;

import java.awt.Window;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class TabHandling {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver d = new ChromeDriver();
		WebDriver d1 = new ChromeDriver();
		
		String prevwin = d.getWindowHandle();
	
		d.get("https://www.w3schools.com/");
		
		d.switchTo().newWindow(WindowType.TAB);
		
		String secondwin = d.getWindowHandle();
		
		d.get("https://www.apple.com/store");
		d.switchTo().window(prevwin);
		
		Thread.sleep(3000);
		//d.getWindowHandle().
		
		d1.get("https://www.changepond.com/");
		d1.switchTo().newWindow(WindowType.TAB);
	}

}
