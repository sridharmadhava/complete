package selenium_Jar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElement_Dropdown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver drop = new ChromeDriver();
		drop.get("https://demo.automationtesting.in/Register.html");
		
		WebElement dropdown = drop.findElement(By.id("yearbox"));
		System.out.println(dropdown.getText());
		
		
		

	}

}
