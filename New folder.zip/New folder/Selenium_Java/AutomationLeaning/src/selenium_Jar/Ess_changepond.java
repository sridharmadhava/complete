package selenium_Jar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ess_changepond {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd = new ChromeDriver();
		
		wd.manage().window().maximize();
		wd.get("https://ess.changepond.com/#/");
		
		wd.findElement(By.id("empid")).sendKeys("4726");
		wd.findElement(By.id("outlined-adornment-password")).sendKeys("8500");
		
		wd.findElement(By.xpath("//button[@type=\"submit\"]")).click();
		
		
		Thread.sleep(3000);
		wd.findElement(By.className("MuiTypography-root MuiTypography-body1 MuiListItemText-primary css-bwghvo")).click();

	}

}
