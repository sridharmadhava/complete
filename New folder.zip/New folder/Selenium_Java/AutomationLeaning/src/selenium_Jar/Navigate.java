package selenium_Jar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Navigate {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver web = new EdgeDriver();
		web.get("https://telusko.com/");
		
		web.navigate().to("https://www.udemy.com/");
		
		Thread.sleep(2000);
		//web.get("https://www.udemy.com/");
//		web.navigate().forward();
		//web.navigate().refresh();
		web.manage().window().maximize();
		System.out.println(web.manage().window().getSize());
		
		web.close();

	}

}
