package selenium_Jar;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Drag_Drop_Automation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver d = new ChromeDriver();
		d.get("https://demo.automationtesting.in/Static.html");
		
		d.manage().window().maximize();
		
		Actions action = new Actions(d);
		
		
		WebElement drag = d.findElement(By.id("angular"));
		WebElement drop = d.findElement(By.id("droparea"));
		
		action.dragAndDrop(drag, drop).build().perform();
		
		
		WebElement drag1 = d.findElement(By.id("mongo"));
		WebElement drop1 = d.findElement(By.id("droparea"));
		action.dragAndDrop(drag1, drop1).build().perform();
		action.dragAndDrop(drag1, drop1).build().perform();
		action.dragAndDrop(drag1, drop1).build().perform();

	}

}
