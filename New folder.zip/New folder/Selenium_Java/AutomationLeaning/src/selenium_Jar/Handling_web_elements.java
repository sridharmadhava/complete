package selenium_Jar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Handling_web_elements {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver Driver = new ChromeDriver();
		String s= "https://www.saucedemo.com/v1/";
		Driver.get(s);
		
		Driver.manage().window().maximize();
		
		Driver.findElement(By.id("user-name")).sendKeys("standard_user");
		
		Driver.findElement(By.name("password")).sendKeys("secret_sauce");
		
		Driver.findElement(By.id("login-button")).click();
		
		Thread.sleep(2000);
		
		Driver.navigate().to("https://www.udemy.com/");
		Driver.navigate().back();
		

	}

}
