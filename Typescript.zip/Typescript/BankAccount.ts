import { BankAccount } from "./Bank1";
let bank = new BankAccount("Sridhar Mandava",270801510072,525);
 
bank.deposit(3500);
 
bank.withdraw(30)
 
bank.displaybalance();