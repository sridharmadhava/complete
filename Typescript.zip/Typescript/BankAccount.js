"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Bank1_1 = require("./Bank1");
var bank = new Bank1_1.BankAccount("Sridhar Mandava", 270801510072, 525);
bank.deposit(3500);
bank.withdraw(30);
bank.displaybalance();
