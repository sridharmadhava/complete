"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.product = void 0;
//product.ts
var product = /** @class */ (function () {
    function product(id, name, price) {
        this.Id = id;
        this.Name = name;
        this.Price = price;
    }
    return product;
}());
exports.product = product;
