var User = /** @class */ (function () {
    function User() {
        this.userid = "ramu111@gmail.com";
    }
    Object.defineProperty(User.prototype, "_userid", {
        get: function () {
            return this.userid;
        },
        set: function (val) {
            this.userid = val;
        },
        enumerable: false,
        configurable: true
    });
    User.prototype.userDetails = function () {
        return "UserId:".concat(this.userid, " password:").concat(this.upass);
    };
    return User;
}());
var userObj = new User();
console.log(userObj._userid);
