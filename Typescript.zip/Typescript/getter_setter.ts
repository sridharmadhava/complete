

class User{
    private userid:string= "ramu111@gmail.com";
    private upass:string;

    get _userid(){
        return this.userid
    }
    set _userid(val:any){
        this.userid = val;

    }

    userDetails(){
        return `UserId:${this.userid} password:${this.upass}`

    }

}
let userObj = new User();
console.log(userObj._userid);

userObj._userid='hari@gmail.com'
console.log(userObj._userid);