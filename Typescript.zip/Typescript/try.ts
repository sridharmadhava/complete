class EmployeeSalary {
    employeeId: number;
    employeeName: string;
    basicSalary: number;
    hra: number;
    da: number;
    grossSalary: number;

    constructor(employeeId: number, employeeName: string, basicSalary: number) 
    {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.basicSalary = basicSalary;

        this.hra = this.basicSalary * 0.20; 
        this.da = this.basicSalary * 0.10;  
        this.grossSalary = this.basicSalary + this.hra + this.da;
    }

    displayDetails(): void {
        console.log(`Employee ID: ${this.employeeId}`);

        console.log(`Employee Name: ${this.employeeName}`);

        console.log(`Basic Salary: ${this.basicSalary.toFixed(2)}`);

        console.log(`HRA (20%): ${this.hra.toFixed(2)}`);

        console.log(`DA (10%): ${this.da.toFixed(2)}`);

        console.log(`Gross Salary: ${this.grossSalary.toFixed(2)}`);
    }
}

const emp = new EmployeeSalary(4726, "Sridhar", 55453);
emp.displayDetails();
