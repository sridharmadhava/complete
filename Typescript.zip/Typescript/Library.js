"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Library = void 0;
var Library = /** @class */ (function () {
    function Library() {
        this.books = [];
    }
    Library.prototype.addBook = function (book) {
        this.books.push(book);
    };
    Library.prototype.removeBook = function (Bnumber) {
        this.books = this.books.filter(function (book) { return book.Bnumber !== Bnumber; });
    };
    Library.prototype.listBooks = function () {
        this.books.forEach(function (book) {
            console.log("".concat(book.title, " by ").concat(book.author, " (Bnumber: ").concat(book.Bnumber, ")"));
        });
    };
    return Library;
}());
exports.Library = Library;
