let person={
    id:101,
    name:"Ramu",
    designation :"Software tester",
    Single: true,
    Address: {
        city:"Vizag",
        pin:530017,
        state:"Andhra pradesh"
    },
    details: function()
    {
        return `ID:${this.id} Name:${this.name} Designation:${this.designation} Single:${this.Single}
        City:${this.Address.city} State:${this.Address.state}`

    }

}
// console.log(`ID:${person.id} Name:${person.name} Designation:${person.designation} Single:${person.Single}
//         City:${person.Address.city} State:${person.Address.state}`);

        console.log(person.details());