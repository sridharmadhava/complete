
// let addition1 ={num1+num2}=>{
//     return num1+num2;
// }


// let addition =(num1,num2)=> num1+num2;

// console.log(addition(554,56));
// console.log(addition(700,200));
// console.log(addition(600,500));



// function demo()
// { 
//     let count = 1; 
//     count++; 
//     console.log(count); 
// } 
// demo(); 
// demo(); 
// demo(); 
// demo();

function outerfunction(){
    let count=0;

    function innerfunction(){
        count++;
        console.log(count);
    }
    return innerfunction;
}


let count =outerfunction();
count();
count();
count();