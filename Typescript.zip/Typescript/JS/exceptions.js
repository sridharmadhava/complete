try{
    //console.log("this is try block")
    let x=123;
    if(x=="") throw new errror ('x is empty');
    if(isNaN(x)) throw new errror ('x do not  have a number data types');
    x= Number(x);
    if(x < 5) throw new error()
}catch(error){
    console.log(error.message)
};

prom