


function one(){
    console.log("Function One called"); 
}

function two(){
   setTimeout(()=>{
     console.log("Function Two called"); 
    }, 1000)
}

function Three(){
    console.log("Function Three called"); 
}

one();
two();
Three();