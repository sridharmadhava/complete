

// function myValue(data){
//     console.log(`My value is :${data}`);
// }

// let myPromises = new Promise((resolve,rejected)=>
//     {
//     let x=6;
//     if(x==0) {
//        resolve("Promis is Solved");
//     }
//     else{
//         rejected(" Promis is not Solved")
//     }
//     }
// );


// //consuming code
// myPromises.then((Value)=>{myValue(Value)},(error)=>{myValue(error)});



function getData(){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve('Code is resolved');
        },2000);
    });
};
 
 
async function greetings(){
    let data = await getData();
    console.log(data);
}
 
greetings();