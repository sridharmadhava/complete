import { myfullName,product} from "./mydata";
import { addition } from "./addition";
console.log(myfullName);
 
let pobj = new product(4720,"Ramu",8500);
console.log(pobj.productDetails());
console.log(addition(20,30));