var Student = /** @class */ (function () {
    function Student(name, rollNo, maths, telugu, social) {
        this.marks = [0, 0, 0]; // [Maths, Telugu, Social]
        this.name = name;
        this.rollNo = rollNo;
        this.setMarks(maths, telugu, social);
    }
    Student.prototype.setMarks = function (maths, telugu, social) {
        this.marks = [maths, telugu, social];
    };
    Student.prototype.getTotal = function () {
        return this.marks.reduce(function (a, b) { return a + b; }, 0);
    };
    Student.prototype.getAverage = function () {
        return this.getTotal() / 3;
    };
    Student.prototype.getGrade = function () {
        var avg = this.getAverage();
        return avg >= 75 ? 'A' : avg >= 50 ? 'B' : 'C';
    };
    Student.prototype.display = function () {
        console.log("Name: ".concat(this.name));
        console.log("Roll No: ".concat(this.rollNo));
        console.log("Maths: ".concat(this.marks[0], ", Telugu: ").concat(this.marks[1], ", Social: ").concat(this.marks[2]));
        console.log("Total: ".concat(this.getTotal()));
        console.log("Average: ".concat(this.getAverage().toFixed(2)));
        console.log("Grade: ".concat(this.getGrade()));
    };
    return Student;
}());
var Marks = new Student("Ramu Mandava ", 20345, 85, 65, 93);
Marks.display();
