// Library.ts
import { Book } from './Book';

export class Library {
  private books: Book[] = [];

  addBook(book: Book): void {
    this.books.push(book);
  }

  removeBook(Bnumber: number): void {
    this.books = this.books.filter(book => book.Bnumber !==Bnumber);
  }

  listBooks(): void {
    this.books.forEach(book => {
      console.log(`${book.title} by ${book.author} (Bnumber: ${book.Bnumber})`);
    });
  }
}
