//product.ts
export class product {
    Id :number;
    Name : string;
    Price : number;
 
    constructor(id:number,name:string,price:number){
        this.Id =id;
        this.Name = name;
        this.Price = price;
    }
}