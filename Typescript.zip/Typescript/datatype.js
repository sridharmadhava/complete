//console.log("Helooe ");
//String dat type
var myName = "Sridhar";
console.log(myName);
//number data type
var no1 = 1000, no2 = 0.5, no3 = 12312;
console.log(no1);
console.log(no2);
console.log(no3);
//Boolean data types
var cond1 = true, cond2 = false;
console.log(cond1);
console.log(cond2);
//array data type
var courses = ["DSA", "Java", "DMS", "Database"];
console.log(courses);
var breakfast = ["Idali", "Dosa", "Upma", "Poori"];
console.log(breakfast);
//tupple data type
var item = ["Samosa", 30];
console.log(item);
//enum : it is create constant variables with fix value
var days;
(function (days) {
    days[days["sun"] = 0] = "sun";
    days[days["mon"] = 1] = "mon";
    days[days["tues"] = 2] = "tues";
    days[days["wed"] = 3] = "wed";
    days[days["thu"] = 4] = "thu";
    days[days["fri"] = 5] = "fri";
    days[days["sat"] = 6] = "sat";
})(days || (days = {}));
;
var data1 = days.sun;
console.log(days);
//7. Union : It allows us to store value with different data types.
var information1 = "Changepond";
console.log(information1);
var information2 = "IBM";
console.log(information2);
//8. Any : when we don't what information is going to be store in variable
var data = 1234;
console.log(data);
