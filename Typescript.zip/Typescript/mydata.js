"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.product = exports.myfullName = void 0;
exports.myfullName = "Sridhar mandava";
var product = /** @class */ (function () {
    function product(id, name, price) {
        this.pId = id;
        this.pName = name;
        this.pPrice = price;
    }
    product.prototype.productDetails = function () {
        return "Id:".concat(this.pId, "    Name:").concat(this.pName, "   Price:").concat(this.pPrice);
    };
    return product;
}());
exports.product = product;
