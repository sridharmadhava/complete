"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addition = void 0;
var addition = function (num1, num2) {
    return num1 + num2;
};
exports.addition = addition;
