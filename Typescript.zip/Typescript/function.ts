

let evenNumber = (num)=>{

    return (num%2==0) ? `${num} even number` : `${num} odd number`;

    
}
console.log(evenNumber(99));
