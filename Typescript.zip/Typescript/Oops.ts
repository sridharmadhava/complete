class Emp{
    eID:number=101;
    eName:string="Sridhar";
    esalary:number=69000;
    eSingle:boolean=true;

    

    //create constructor
    constructor(id: number,name: string,salary:number,isSingle:boolean){
        this.eID = id;
        this.eName = name;
        this.eSingle = isSingle;
        this.esalary = salary;
    }


    //Member- function 
    employeedetails(){
        return `Id:${this.eID}    Name:${this.eName}    Salary:${this.esalary}    Single:${this.eSingle} `

        
    }

}



//How to create Object of class




let empObj1 = new Emp(109,"Rani",95000,true);
console.log(empObj1.eName);
console.log(empObj1.employeedetails());

class Company extends Emp{

    cName : string;
    cAddress : string;

    constructor(id: number,name: string,salary:number,Single:boolean, compName: string, compAddr:string){
        super(id,name,salary,Single)
        this.cName = compName;
        this.cAddress=compAddr;
   
    }

    employeeDetails(){
        return `Id:${this.eID} Name:${this.eName} Salary:${this.esalary} Single:${this.eSingle} company Name:${
            this.cName} Address:${this.cAddress}`;
        
    }
};

let companyObj = new Company(301,"Tiger", 75000, false,"IBM", "Hyd");
console.log(companyObj.employeeDetails());