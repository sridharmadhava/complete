"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mydata_1 = require("./mydata");
var addition_1 = require("./addition");
console.log(mydata_1.myfullName);
var pobj = new mydata_1.product(4720, "Ramu", 8500);
console.log(pobj.productDetails());
console.log((0, addition_1.addition)(20, 30));
