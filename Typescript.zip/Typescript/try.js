var EmployeeSalary = /** @class */ (function () {
    function EmployeeSalary(employeeId, employeeName, basicSalary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.basicSalary = basicSalary;
        this.hra = this.basicSalary * 0.20;
        this.da = this.basicSalary * 0.10;
        this.grossSalary = this.basicSalary + this.hra + this.da;
    }
    EmployeeSalary.prototype.displayDetails = function () {
        console.log("Employee ID: ".concat(this.employeeId));
        console.log("Employee Name: ".concat(this.employeeName));
        console.log("Basic Salary: ".concat(this.basicSalary.toFixed(2)));
        console.log("HRA (20%): ".concat(this.hra.toFixed(2)));
        console.log("DA (10%): ".concat(this.da.toFixed(2)));
        console.log("Gross Salary: ".concat(this.grossSalary.toFixed(2)));
    };
    return EmployeeSalary;
}());
var emp = new EmployeeSalary(4726, "Sridhar", 55453);
emp.displayDetails();
