

//console.log("Helooe ");
//String dat type
let myName:string = "Sridhar";
console.log(myName);
//number data type
let no1:number=1000, no2:number=0.5,no3:number=12312;
console.log(no1);
console.log(no2);
console.log(no3);

//Boolean data types

let cond1:boolean=true, cond2:boolean=false;
console.log(cond1);
console.log(cond2);


//array data type
let courses:string[]=["DSA","Java","DMS","Database"];
console.log(courses);
let breakfast:Array<string> = ["Idali","Dosa","Upma","Poori"];
console.log(breakfast);

//tupple data type
let item:[String,number] = ["Samosa",30];
console.log(item);

//enum : it is create constant variables with fix value
enum days{sun,mon,tues,wed,thu,fri,sat};
let data1 = days.sun;
console.log(days);

//7. Union : It allows us to store value with different data types.
let information1:string | number = "Changepond";
console.log(information1);
let information2:string | number = "IBM";
console.log(information2);

//8. Any : when we don't what information is going to be store in variable
let data:any = 1234;
console.log(data);
