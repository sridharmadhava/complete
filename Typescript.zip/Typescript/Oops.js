var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Emp = /** @class */ (function () {
    //create constructor
    function Emp(id, name, salary, isSingle) {
        this.eID = 101;
        this.eName = "Sridhar";
        this.esalary = 69000;
        this.eSingle = true;
        this.eID = id;
        this.eName = name;
        this.eSingle = isSingle;
        this.esalary = salary;
    }
    //Member- function 
    Emp.prototype.employeedetails = function () {
        return "Id:".concat(this.eID, "    Name:").concat(this.eName, "    Salary:").concat(this.esalary, "    Single:").concat(this.eSingle, " ");
    };
    return Emp;
}());
//How to create Object of class
var empObj1 = new Emp(109, "Rani", 95000, true);
console.log(empObj1.eName);
console.log(empObj1.employeedetails());
var Company = /** @class */ (function (_super) {
    __extends(Company, _super);
    function Company(id, name, salary, Single, compName, compAddr) {
        var _this = _super.call(this, id, name, salary, Single) || this;
        _this.cName = compName;
        _this.cAddress = compAddr;
        return _this;
    }
    Company.prototype.employeeDetails = function () {
        return "Id:".concat(this.eID, " Name:").concat(this.eName, " Salary:").concat(this.esalary, " Single:").concat(this.eSingle, " company Name:").concat(this.cName, " Address:").concat(this.cAddress);
    };
    return Company;
}(Emp));
;
var companyObj = new Company(301, "Tiger", 75000, false, "IBM", "Hyd");
console.log(companyObj.employeeDetails());
