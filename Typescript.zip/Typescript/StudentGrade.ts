interface StudentDetails {
  name: string;
  rollNo: number;
  setMarks(maths: number, telugu: number, social: number): void;
  getTotal(): number;
  getAverage(): number;
  getGrade(): string;
}

class Student implements StudentDetails {
  name: string;
  rollNo: number;
  private marks: number[] = [0, 0, 0]; // [Maths, Telugu, Social]

  constructor(name: string, rollNo: number, maths: number, telugu: number, social: number) {
    this.name = name;
    this.rollNo = rollNo;
    this.setMarks(maths, telugu, social);
  }

  setMarks(maths: number, telugu: number, social: number): void {
    this.marks = [maths, telugu, social];
  }

  getTotal(): number {
    return this.marks.reduce((a, b) => a + b, 0);
  }

  getAverage(): number {
    return this.getTotal() / 3;
  }

  getGrade(): string {
    const avg = this.getAverage();
    return avg >= 75 ? 'A' : avg >= 50 ? 'B' : 'C';
  }

  display(): void {
    console.log(`Name: ${this.name}`);
    console.log(`Roll No: ${this.rollNo}`);
    console.log(`Maths: ${this.marks[0]}, Telugu: ${this.marks[1]}, Social: ${this.marks[2]}`);
    console.log(`Total: ${this.getTotal()}`);
    console.log(`Average: ${this.getAverage().toFixed(2)}`);
    console.log(`Grade: ${this.getGrade()}`);
  }
}


const Marks = new Student("Ramu Mandava ", 20345, 85, 65, 93);
Marks.display();

