"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Book = void 0;
var Book = /** @class */ (function () {
    function Book(title, author, Bnumber) {
        this.title = title;
        this.author = author;
        this.Bnumber = Bnumber;
    }
    return Book;
}());
exports.Book = Book;
