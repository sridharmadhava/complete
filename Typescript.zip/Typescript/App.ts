
import { Book } from './Book';
import { Library } from './Library';

const library = new Library();

const book1 = new Book('Money Daddy', 'Sridhar', 341);
const book2 = new Book('The Karma', 'Ramu', 143);

library.addBook(book1);
library.addBook(book2);

console.log('All books:');
library.listBooks();

library.removeBook(341);

console.log('\nAfter removing 1984:');
library.listBooks();
