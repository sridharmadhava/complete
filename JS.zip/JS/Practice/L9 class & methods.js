//Class & Methods

import { customerDetails } from "./Helpers/printHelper.js";

//var customerDetails = new CustomerDetails()
customerDetails.printFirstName('Sridhar')
customerDetails.printLastName('Madhava')