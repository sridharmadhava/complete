

var customerFirstName: string =" Ramu"
var customerLastName: string ='Madhava'
var customerAge: number = 23

type Customer = {firstName: string, lastName:string, active: boolean}

var firstCustomer: Customer = {
    firstName: "Aparna",
    lastName: "Mandava",
    active: true
}
var firstCustomer: Customer = {
    firstName: "Aparna",
    lastName: "Mandava",
    active: true
}