//Relational and Equality Operators

// > - More than
// < - Less Than
// >= - more than Equal
// <= - Less than Equal

var result = 6 <= 5
//console.log(result)

//Equalit Operators

var x =1
console.log(x =='1') //lose comparison

console.log(x ===1) // Strict comparison