//Objects

var customer ={
    FirstName: 'Sridhar',
    LastName: 'Mandava',

    Car: ['Volvo',"Toyota","BMW","BYD",'Tesla']

}
//Dot Notation 
customer.FirstName='Ramu'
// Bracket Notation
customer['LastName'] = "Kasinanli"
console.log(`${customer.FirstName} ${customer.LastName}`)

//console.log(customer.FirstName +" "+ customer.LastName)

//Arrays
var Car = ['Volvo',"Toyota","BMW","BYD",'Tesla']
Car[3]='Tata' // Replaced value
console.log(Car[3])
console.log(customer.Car[0])



