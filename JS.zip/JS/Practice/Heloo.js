//First JS file

console.log("Hello Sridhar ")


console.log("My first JS exection : Sridhar ")

//Variables
var FirstName="Sridhar"
let LastName="Mandava"

console.log(LastName)


var age, DOB, Sex
age = "23"
Sex = "Male"
console.log(age)
age ="45"
console.log(age)

//Constants -- Defined in JS With Keyword Const

const occupation = "Tester"
console.log(occupation)

//Data Types

var MiddleName="Ramu" //String
var ageOfPerson = 56 // Number
var isHeMarried = false //Boolean
var YearInMarriage = null //Null - No value
var NumberOfCars = undefined  //undefined