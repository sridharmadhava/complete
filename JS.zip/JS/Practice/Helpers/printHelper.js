

export function printAge(age){
    console.log(age)
}

class CustomerDetails{

    printFirstName(firstName){
        console.log(firstName)
    }

    /**
     * This method will print the last Name
     * @param {String} LastName 
     */

    printLastName(LastName){
        console.log(LastName)
    }
}

export const customerDetails = new CustomerDetails()