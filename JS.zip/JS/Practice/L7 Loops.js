//Loops

// console.log("Hey sridhar")
// console.log("Hey sridhar")
// console.log("Hey sridhar")
// console.log("Hey sridhar")
// console.log("Hey sridhar")

// // for Loops
// for(statement1; statement2; statement3){


// }

for(let i =1; i<=5; i++){
    console.log("Hey sridhar"+ i)


}

var Cars = ['Volvo',"Toyota","BMW","BYD","Tesla"]
//For of loop
for(let c of Cars){
    console.log(c)
    if(c == "BMW"){
        break
    }

}

console.log("------------------------------------")

//ES6 Syntax for each loop
Cars.forEach( c =>{
     console.log(c)
})
