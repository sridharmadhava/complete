//Logical Operators.

//Logical  "AND"

//console.log(true && false) // all values have to be true for expression to be TRUE


//Logical "OR" --> ||

//console.log(true || false) // All Values Should be True for the Expression to be TRUE, Any one condition should be true


var ageIsMoreThanEighteen = true
var isIndianCitizen = false

var eliqibilityForDriversLicence = ageIsMoreThanEighteen || isIndianCitizen
console.log('This Person is eligible for DL: '+ eliqibilityForDriversLicence)

//Logical "NOT"
//console.log(!false)
console.log(6!== 10) //opposite sign