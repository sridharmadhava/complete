//Concatination and interpolation

var Price = 25
var ItemName = "Cab"
var messageToPrint1 = "The Price for Your " + ItemName +" is " + Price + " Lakhs" //Concatination
var messageToPrint2 =`The Price Foe Your ${ItemName} is ${Price} Lakhs` //interpolation

console.log(messageToPrint1)
console.log(messageToPrint2)