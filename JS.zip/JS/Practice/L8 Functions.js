//Functions

//Declarative Function
helloOne()
function helloOne(){
    console.log("Hello143")
}
// helloOne()
// helloOne()

// Anoymus Function
let helloTwo = function(){
     console.log("Hello1423!")

}
helloTwo()

//ES6 Function Syntax or Arrow Function
var HelloThree = () =>{
    console.log("Coolie")
    
}
HelloThree()

//Function with arguments
function printName(name, LastName){
    console.log(name+' '+ LastName )

}
printName('Sridhar', "Mandava")

//Function With return
function multiplyByTwo(number){
    var result = number * 2
    return result
}
var myResult = multiplyByTwo(5)
console.log(myResult)

//import function
import{ printAge } from  './Helpers/printHelper.js'
printAge(53)

//import everything
import * as help from "./Helpers/printHelper.js" //We can give any word
help.printAge(23)