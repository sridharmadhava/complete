//Conditional Statements

// if(Conditional){
//     //Execute some code here

// }
// else{
//     //Execute some code here
// }

//If hour between 6 and 12 print "Good Morning"
//If Hour between 12 and 18 print "Good Afternoon"
//Otherwise : Print Good Evening


// var hour=1
// if(hour>=6 && hour<12){
//     console.log('Good Morning')

// }
// else if( hour>=12 && hour<18)
// {
//     console.log("Good Afternoon")
// }
// else {
//     console.log("Good Evening")
// }

var ageIsMoreThanEighteen = true
var isIndianCitizen = false

if(ageIsMoreThanEighteen && isIndianCitizen)
{
    console.log('customer is eligible for DL')
}
else{
    console.log('customer is not eligible for DL')
}