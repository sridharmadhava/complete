export const users:any[] = [
    {username:"standard_user", password:"secret_sauce",testCaseMsg:"login with valid credential"},
    {username:"locked_out_user", password:"secret_sauce",testCaseMsg:"login with locked user"}
]