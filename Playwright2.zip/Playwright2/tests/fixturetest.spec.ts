import { test } from "./fixture"

 
test ("hello fixture test",({Hollywood})=>{
    console.log(Hollywood)
    console.log("Did you had lunch");
})
 
test("Ramu test",({greatDay})=>{
    console.log(greatDay)
    console.log("I am Employee of changepond")
})

////////////////////////////////

// import{test} from './fixture'
 
// test ("hello fixture test",({hello})=>{
//     console.log(hello)
//     console.log("Did you had lunch");
// })
 
// test("Raju test",({greatday})=>{
//     console.log(greatday)
//     console.log("I am Employee of changepond")
// })